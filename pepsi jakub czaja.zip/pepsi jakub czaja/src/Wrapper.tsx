import React = require('react');

export const Wrapper: React.FC = () => (
  <div className="wrapper">
    <div className="hero-bg"></div>
    <div className="clip-video"></div>
  </div>
);
