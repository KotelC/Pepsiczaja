import * as React from 'react';


export const Content: React.FC = () => (
  <div className="content">
    <h1>Lorem ipsum dolor sit amet consectetur adipisicing elit.</h1>

    <button>kup teraz</button>
  </div>
);
