import * as React from 'react';
import logo from './Pepsi_logo_(2014).svg';


export const Nav: React.FC = () => (
  <nav>
    <img src="./Pepsi_logo_(2014).svg" alt="logo" className="logo" />
    <ul>
      <li>
        <a href="#">Home</a>
      </li>
      <li>
        <a href="#">Blog</a>
      </li>
      <li>
        <a href="#">Contact</a>
      </li>
      <li>
        <img src="./menu.png" alt="menu" className="menu" />
      </li>
    </ul>
  </nav>
);
